import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  products: [],
}

const apislice = createSlice({
  name: "api",
  initialState,
  reducers: {
    fetching: (state, action) => {
        state.products =action.payload
    },

  },
})

export const { fetching } = apislice.actions
export default apislice.reducer

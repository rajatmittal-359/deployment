import React, { useState, useEffect } from "react";
import axios from "axios";
import { useDispatch } from "react-redux";
import { fetching } from "./features/slice/apislice";
const Home = () => {
  const dispatch = useDispatch()
   const fetchdata = async () => {
      const result = await axios.get("https://fakestoreapi.com/products");
      dispatch(fetching(result.data))
    };
  
    useEffect(() => {
      fetchdata();
    }, []);
  
  return (
    <div className="text-4xl flex justify-center ">Welcome to Shopping site</div>
  )
}

export default Home